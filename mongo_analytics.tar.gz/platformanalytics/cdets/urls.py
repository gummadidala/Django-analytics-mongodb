from django.conf.urls import url
from cdets import views
urlpatterns = [
    url(r'^api/plotcdets/', views.CdetsPlotAPIView.as_view()),
    url(r'^api/cdetsdata/', views.CdetsdataAPIView.as_view()),
    url(r'^api/cdetsversions/', views.CdetsVersionsAPIView.as_view()),
]