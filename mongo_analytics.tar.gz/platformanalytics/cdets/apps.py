from django.apps import AppConfig


class CdetsConfig(AppConfig):
    name = 'cdets'
