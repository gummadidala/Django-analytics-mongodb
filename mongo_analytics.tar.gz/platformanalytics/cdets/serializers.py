from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from cdets.models import *

class CdetsdataSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Cdetsdata
        fields = ['id', 'Identifier', 'Project', 'Product', 'Submitter', 
                  'Status', 'Severity', 'Submitted_date', 'Component', 
                  'Updated_date', 'Impact', 'Version', 'Attribute', 'Found', 
                  'Count', 'Automated_test', 'Bug_origin', 'Dev_escape', 'Resolved_date']