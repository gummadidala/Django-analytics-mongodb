from __future__ import unicode_literals
import binascii, os
from django.db import models
import uuid
from django.utils import timezone
import mongoengine
from mongoengine import Document, fields, EmbeddedDocument
from mongoengine import signals
from mongoengine.django.auth import User
from dateutil.parser import parse

class Cdetsdata(Document):
    Identifier = fields.StringField(default="", null=True)
    Project = fields.StringField(default="", null=True)
    Product = fields.StringField(default="", null=True)
    Submitter = fields.StringField(default="", null=True)
    Status = fields.StringField(default="", null=True)
    Severity = fields.StringField(default="", null=True)
    Submitted_date = fields.DateTimeField(null=True)
    Component = fields.StringField(default="", null=True)
    Updated_date = fields.DateTimeField(null=True)
    Impact = fields.StringField(default="", null=True)
    Version = fields.StringField(default="", null=True)
    Attribute =fields.StringField(default="", null=True)
    Found = fields.StringField(default="", null=True)
    Count = fields.IntField()
    Resolved_date = fields.DateTimeField(null=True)
    Automated_test = fields.StringField(default="", null=True)
    Bug_origin = fields.StringField(default="", null=True)
    Dev_escape = fields.StringField(default="", null=True)