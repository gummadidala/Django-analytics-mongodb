from django.conf.urls import url
from common import views
urlpatterns = [
    url(r'^api/business/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.BusinessUpdateAPIView.as_view()),
    url(r'^api/business/', views.BusinessAPIView.as_view()),
    url(r'^api/product/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.ProductUpdateAPIView.as_view()),
    url(r'^api/product/', views.ProductAPIView.as_view()),
    url(r'^api/plot/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.PlotUpdateAPIView.as_view()),
    url(r'^api/plot/', views.PlotAPIView.as_view()),
    url(r'^api/cluster/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.ClusterUpdateAPIView.as_view()),
    url(r'^api/cluster/', views.ClusterAPIView.as_view()),
    url(r'^api/preferencetype/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.PreferenceTypeUpdateAPIView.as_view()),
    url(r'^api/preferencetype/', views.PreferenceTypeAPIView.as_view()),
]