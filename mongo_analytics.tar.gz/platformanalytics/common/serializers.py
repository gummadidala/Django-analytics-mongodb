from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from common.models import *

class PreferenceTypeSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = PreferenceType
        fields = ['key','name']

class BusinessSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Business
        fields = ['key','name']
        
class PlotSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Plot
        fields = ['key','name']
    
class PlotWriteSerializer(mongoserializers.DocumentSerializer):
    product = serializers.SlugRelatedField(
        queryset=Product.objects.all(),
        slug_field='key')
    class Meta:
        model = Plot
        fields = ['key','name','product']

class ClusterSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Cluster
        fields = ['key','name']
    
class ClusterWriteSerializer(mongoserializers.DocumentSerializer):
    product = serializers.SlugRelatedField(
        queryset=Product.objects.all(),
        slug_field='key')
    class Meta:
        model = Cluster
        fields = ['key','name','product']

class ProductSerializer(mongoserializers.DocumentSerializer):
    plots = PlotSerializer(many=True)
    clusters = ClusterSerializer(many=True)
    business = serializers.SlugRelatedField(
        queryset=Business.objects.all(),
        slug_field='name')
    class Meta:
        model = Product
        fields = ['key','name','business','plots','clusters']
class ProductShortSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Product
        fields = ['key','name']

class ProductWriteSerializer(mongoserializers.DocumentSerializer):
    business = serializers.SlugRelatedField(
        queryset=Business.objects.all(),
        slug_field='key')
    clusters = serializers.SlugRelatedField(
        queryset=Cluster.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    plots = serializers.SlugRelatedField(
        queryset=Plot.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    class Meta:
        model = Product
        fields = ['key','name','business',"plots","clusters"]