from __future__ import unicode_literals

from django.db import models
import uuid
from django.utils import timezone
from mongoengine import Document, fields, EmbeddedDocument
import mongoengine
# Create your models here.

class Business(Document):
    key = fields.UUIDField(default=uuid.uuid4)
    name = fields.StringField(required=True, null=True)

class Plot(Document):
    key = fields.UUIDField(default=uuid.uuid4)
    name = fields.StringField(required=True, null=True)

class Cluster(Document):
    key = fields.UUIDField(default=uuid.uuid4)
    name = fields.StringField(required=True, null=True)

class Product(Document):
    key = fields.UUIDField(default=uuid.uuid4)
    name = fields.StringField(required=True, null=True)
    business = fields.ReferenceField(Business, dbref=True)
    plots = fields.ListField(fields.ReferenceField(Plot, dbref=True))
    clusters = fields.ListField(fields.ReferenceField(Cluster, dbref=True))

class PreferenceType(Document):
    key = fields.UUIDField(default=uuid.uuid4)
    name = fields.StringField(required=True, null=True)