from rest_framework_mongoengine import generics
from common.models import *
from common.serializers import *
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from users.authentication import TokenAuthentication, ExpiringTokenAuthentication
from mongoengine.django.auth import User
from users.models import *

class BusinessAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = BusinessSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Business.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BusinessSerializer
        return BusinessSerializer

class BusinessUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = BusinessSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Business.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return BusinessSerializer
        return BusinessSerializer
    
class PreferenceTypeAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = PreferenceTypeSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceType.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PreferenceTypeSerializer
        return PreferenceTypeSerializer

class PreferenceTypeUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = PreferenceTypeSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceType.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PreferenceTypeSerializer
        return PreferenceTypeSerializer

class ProductAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = ProductSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Product.objects.all()
   
    def post(self,request,format=None):
        parsed_data = request.data
        if 'clusters' in parsed_data:
            clusters = []
            in_clusters = parsed_data['clusters']
            for i in in_clusters:
                obj = Cluster()
                obj.name = i
                obj.save()
                clusters.append(str(obj.key))
            parsed_data['clusters'] = clusters
        if 'plots' in parsed_data:
            plots = []
            in_plots = parsed_data['plots']
            for i in in_plots:
                obj = Plot()
                obj.name = i
                obj.save()
                plots.append(str(obj.key))
            parsed_data['plots'] = plots
        if 'business' not in parsed_data:
            parsed_data['business'] = None
        serializer = ProductWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            usrs = User.objects.all()
            for usr in usrs:
                user_pref_obj = UserPreference()
                user_pref_obj.product = Product.objects.filter(key = str(serializer.instance.key))[0]
                user_pref_obj.pref_type = PreferenceType.objects.filter(name="UI")[0]
                user_pref_obj.user = usr
                user_pref_obj.save()
                if len(serializer.instance.clusters)>0:
                    for cluster in serializer.instance.clusters:
                        pref_map_obj = PreferenceMapping()
                        pref_map_obj.save()
                        pref_map_obj.plots = serializer.instance.plots
                        pref_map_obj.clusters = [cluster]
                        pref_map_obj.save()
                        user_pref_obj.pref_mappings.append(pref_map_obj)
                        user_pref_obj.save()
                else:
                    pref_map_obj = PreferenceMapping()
                    pref_map_obj.save()
                    pref_map_obj.plots = serializer.instance.plots
                    pref_map_obj.clusters = serializer.instance.clusters
                    pref_map_obj.save()
                    user_pref_obj.pref_mappings = [pref_map_obj]
                user_pref_obj.save()    
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)    
    
class ProductUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = ProductSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Product.objects.all()
    
    def patch(self,request,key,format=None):
        parsed_data = request.data
        user_pref_objs = UserPreference.objects.filter(product__key=str(key))
        if 'plots' in parsed_data and len(parsed_data['plots'])>0:
            updated_plots = []
            for plot in parsed_data['plots']:
                obj = Plot.objects.filter(name=plot)
                if obj is not None and len(obj)>0:
                    updated_plots.append(str(obj[0].key))
                else:
                    obj = Plot()
                    obj.name = plot
                    obj.save()
                    updated_plots.append(str(obj.key))
                    for usr_pref in user_pref_objs:
                        for pf in usr_pref.pref_mappings:
                            pf.plots.append(obj)
                            pf.save()
                            usr_pref.save()
                        usr_pref.save()
            parsed_data['plots'] = updated_plots
        if 'clusters' in parsed_data and len(parsed_data['clusters'])>0:
            updated_clusters = []
            for cluster in parsed_data['clusters']:
                obj = Cluster.objects.filter(name=cluster)
                if obj is not None and len(obj)>0:
                    updated_clusters.append(str(obj[0].key))
                else:
                    obj = Cluster()
                    obj.name = cluster
                    obj.save()
                    updated_clusters.append(str(obj.key))
                    for usr_pref in user_pref_objs:
                        pref_map = PreferenceMapping()
                        pref_map.save()
                        pref_map.clusters = [obj]
                        pref_map.plots = usr_pref.product.plots
                        pref_map.save()
                        usr_pref.pref_mappings.append(pref_map)
                        usr_pref.save()
            parsed_data['clusters'] = updated_clusters
        
        product = Product.objects.get(key=key)
        if 'name' not in parsed_data:
            parsed_data['name'] = product.name
        serializer = ProductWriteSerializer(product,data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
    
class PlotAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = PlotSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Plot.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PlotWriteSerializer
        return PlotSerializer

class PlotUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = PlotSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Plot.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PlotWriteSerializer
        return ProductSerializer
    
class ClusterAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = ClusterSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Cluster.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ClusterWriteSerializer
        return ClusterSerializer

class ClusterUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = ClusterSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Cluster.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ClusterWriteSerializer
        return ClusterSerializer