from django.apps import AppConfig


class HybridtestConfig(AppConfig):
    name = 'hybridtest'
