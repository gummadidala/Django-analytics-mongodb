from __future__ import unicode_literals
import binascii, os
from django.db import models
import uuid
from django.utils import timezone
import mongoengine
from mongoengine import Document, fields, EmbeddedDocument
from mongoengine import signals
from mongoengine.django.auth import User
from dateutil.parser import parse

class Hybridtest(Document):
    date = fields.DateTimeField()
    outcome = fields.StringField(default="", null=True)
    exitcode = fields.StringField(default="", null=True)
    exitreason = fields.StringField(default="", null=True)
    calltest = fields.StringField(default="", null=True)
    calendartest = fields.StringField(default="", null=True)
    count = fields.IntField()
    meta = {
        'indexes':[{'fields':("date", "outcome", "exitcode", "exitreason", "calltest", "calendartest", "count",), 
                    'unique':True}]
        }