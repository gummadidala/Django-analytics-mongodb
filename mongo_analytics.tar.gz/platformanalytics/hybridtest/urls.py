from django.conf.urls import url
from hybridtest import views
urlpatterns = [
    url(r'^api/plothybridtest/', views.HybridtestPlotAPIView.as_view()),
    url(r'^api/hybridtestdata/', views.HybridtestAPIView.as_view()),
]