from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from hybridtest.models import *

class HybridtestSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Hybridtest
        fields = ["date", "outcome", "exitcode", "exitreason", "calltest", 
                  "calendartest", "count"]