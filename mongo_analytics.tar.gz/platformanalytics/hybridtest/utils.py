from hybridtest.models import *
from mongoengine.queryset.visitor import Q
from datetime import timedelta, datetime
from dateutil.parser import parse
import json
from operator import itemgetter

def re_arrange_dates(query_data, label, min_date, max_date, product=None, cluster=None, plot=None):
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
        
    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['count'] = 0
            obj["call_info"] = []
            query_data.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(query_data, key=lambda x: x['date'])
    
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    
    dataset = {}
    dates = []
    count = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['count'])
        
    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    
    return dataset

def get_graph_types(plot):
    graph_types = ["Stacked","BarLine","HeatMap","HorizontalBar","Line", "Pie", "Bar"]
    return graph_types

def get_ylabels(plot):
    yLabel = "Call Count"
    return yLabel

def get_aggregation_query(plot):
    group_obj = {'_id':
                   {'date':{"month":{'$month':"$date"}
                            ,"day":{'$dayOfMonth':"$date"},
                            "year":{"$year":"$date"}
                            }
                    },
                   'count':{'$sum':'$count'}
                   }
    return group_obj

def get_hybridtest_filter_fields(plot):
    obj = {}
    if plot == "Test Environment Failure":
        obj['field'] = "exitreason"
    elif plot == "CallTest Results":
        obj['field'] = "calltest"
    elif plot == "CalendarTest Results":
        obj['field'] = "calendartest"
    return obj

def get_hybridtest_data(plot,start_date,end_date,mavg):
    res = {}
    datasets = []
    list_query_data = []
    types = []
    filters = get_hybridtest_filter_fields(plot)
    agg_query = get_aggregation_query(plot)
    if "type" in filters:
        types_query = Hybridtest.objects.filter(date__gte=start_date, 
                                                date__lte=end_date).filter(**{filters['col'] : filters['type']}).only(filters['field'])
    else:
        types_query = Hybridtest.objects.filter(date__gte=start_date, 
                                                date__lte=end_date).only(filters['field'])
    
    for qr in types_query:
        if qr[filters['field']] not in types:
            types.append(qr[filters['field']])
    if "NA" in types:
        types.remove("NA")
    for typ in types:
        if 'col' in filters:
            query_res = Hybridtest.objects.filter(**{filters['field'] : typ}).filter(**{filters['col'] : filters['type']}).filter(date__gte=start_date, 
                                                                                                                                  date__lte=end_date).aggregate({"$group":agg_query})
        else:
            query_res = Hybridtest.objects.filter(**{filters['field'] : typ}).filter(date__gte=start_date, 
                                                                                     date__lte=end_date).aggregate({"$group":agg_query})
        
        res_arr= []
        for i in query_res:
            obj = {}
            date_st = str(i['_id']['date']['year'])+'-'+str(i['_id']['date']['month'])+'-'+str(i['_id']['date']['day'])
            obj['count'] = i['count']
            obj['date'] = parse(date_st).date()
            res_arr.append(obj)
        query_res = res_arr
        obj = {}
        obj['type'] = typ
        obj['query_data'] = query_res
        list_query_data.append(obj)
    end_date = end_date +timedelta(days=-1)
    for q_data in list_query_data: 
        res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date)
        datasets.append(res_data)
    
    if len(datasets) > 0:
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types(plot)
        res['yLabel'] = get_ylabels(plot)
    if not res:
        return None
    else:
        return res