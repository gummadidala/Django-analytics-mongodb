from django.conf.urls import url
from users import views
import cucm.views as cucm
import cms.views as cms
import common.views as common
import desk.views as desk
import cdets.views as cdets
import jira.views as jira
import hybridtest.views as hybridtest


urlpatterns = [
    url(r'^api/authenticate/', views.LdapLogin.as_view()),
    url(r'^api/userpreference/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.UserPreferenceUpdateAPIView.as_view()),
    url(r'^api/userpreferences/', views.UserPreferenceAPIView.as_view()),
    url(r'^api/preferencemapping/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.PreferenceMappingUpdateAPIView.as_view()),
    url(r'^api/preferencemapping/', views.PreferenceMappingAPIView.as_view()),
    url(r'^api/customuserpreferences/', views.CustomUserPreferencesAPIView.as_view()),
    
    
    url(r'^api/plotcucm/', cucm.CucmPlotAPIView.as_view()),
    url(r'^api/plotendpoints/', cucm.CucmPlotAPIView.as_view()),
    url(r'^api/cucmdata/', cucm.CucmdataAPIView.as_view()),
    url(r'^api/cucmversion/', cucm.CucmversionAPIView.as_view()),
    url(r'^api/cucmuserinfo/', cucm.CucmuserinfoAPIView.as_view()),
    url(r'^api/cucmtrunk/', cucm.CucmtrunkAPIView.as_view()),
    url(r'^api/cucmdeviceinfo/', cucm.CucmdeviceinfoAPIView.as_view()),
    url(r'^api/endpoints/', cucm.EndpointsAPIView.as_view()),
    url(r'^api/cucmversions/', cucm.CUCMVersionsAPIView.as_view()),
    
    url(r'^api/plotcdets/', cdets.CdetsPlotAPIView.as_view()),
    url(r'^api/cdetsdata/', cdets.CdetsdataAPIView.as_view()),
    url(r'^api/cdetsversions/', cdets.CdetsVersionsAPIView.as_view()),
    
    url(r'^api/plotcms/', cms.CmsPlotAPIView.as_view()),
    url(r'^api/cmsdata/', cms.CmsdataAPIView.as_view()),
    url(r'^api/cmsversions/', cms.CmsVersionsAPIView.as_view()),
    
    url(r'^api/business/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    common.BusinessUpdateAPIView.as_view()),
    url(r'^api/business/', common.BusinessAPIView.as_view()),
    url(r'^api/product/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    common.ProductUpdateAPIView.as_view()),
    url(r'^api/product/', common.ProductAPIView.as_view()),
    url(r'^api/plot/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    common.PlotUpdateAPIView.as_view()),
    url(r'^api/plot/', common.PlotAPIView.as_view()),
    url(r'^api/cluster/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    common.ClusterUpdateAPIView.as_view()),
    url(r'^api/cluster/', common.ClusterAPIView.as_view()),
    url(r'^api/preferencetype/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    common.PreferenceTypeUpdateAPIView.as_view()),
    url(r'^api/preferencetype/', common.PreferenceTypeAPIView.as_view()),
    
    url(r'^api/plotdesk/', desk.DeskPlotAPIView.as_view()),
    url(r'^api/deskdata/', desk.DeskdataAPIView.as_view()),
    
     url(r'^api/plothybridtest/', hybridtest.HybridtestPlotAPIView.as_view()),
    url(r'^api/hybridtestdata/', hybridtest.HybridtestAPIView.as_view()),
    
    url(r'^api/plotjira/', jira.JiraPlotAPIView.as_view()),
    url(r'^api/jiradata/', jira.JiradataAPIView.as_view()),
    url(r'^api/jiraversions/', jira.JiraVersionsAPIView.as_view()),
]