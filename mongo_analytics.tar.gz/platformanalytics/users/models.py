from __future__ import unicode_literals
import binascii, os
import uuid
from django.utils import timezone
import mongoengine
from mongoengine import Document, fields, EmbeddedDocument
from mongoengine.django.auth import User
from common.models import *

# Create your models here.

class Token(Document):
    key = fields.StringField(required=True)
    user = fields.ReferenceField(User, reverse_delete_rule=mongoengine.CASCADE)
    created = fields.DateTimeField(default=timezone.now)

    def save(self, *args, **kwargs):
        if not self.key:
            self.key = self.generate_key()
        return super(Token, self).save(*args, **kwargs)

    def generate_key(self):
        return binascii.hexlify(os.urandom(20)).decode()

    def __str__(self):
        return self.key
    
class PreferenceMapping(Document):
    key = fields.UUIDField(default=uuid.uuid4)
    clusters = fields.ListField(fields.ReferenceField(Cluster))
    plots = fields.ListField(fields.ReferenceField(Plot))
        
class UserPreference(Document):
    key = fields.UUIDField(default=uuid.uuid4)
    user = fields.ReferenceField(User, reverse_delete_rule=mongoengine.CASCADE)
    product = fields.ReferenceField(Product, reverse_delete_rule=mongoengine.CASCADE)
    pref_mappings = fields.ListField(fields.ReferenceField(PreferenceMapping))
    pref_type = fields.ReferenceField(PreferenceType,default="UI")
    
    meta = {
        'indexes':[{'fields':("product","user","pref_type",), 'unique':True}]
        }