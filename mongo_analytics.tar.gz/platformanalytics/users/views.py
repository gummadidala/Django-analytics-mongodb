from rest_framework_mongoengine import generics
from users.models import *
from mongoengine.django.auth import User
from django.utils import timezone
from  ldap3 import Server, Connection, ALL
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from datetime import datetime, date
from Crypto.Cipher import AES
import base64
from users.authentication import TokenAuthentication, ExpiringTokenAuthentication
from users.serializers import *

def create_preference_mappings(prod):
    preference_mappings = []
    clusters = prod.clusters
    if len(clusters) > 0:
        for cluster in clusters:
            preference_mappping = PreferenceMapping()
            preference_mappping.save()
            preference_mappping.plots = prod.plots
            preference_mappping.clusters = [cluster]
            preference_mappping.save()
            preference_mappings.append(preference_mappping)
    else:
        preference_mappping = PreferenceMapping()
        preference_mappping.save()
        preference_mappping.plots = prod.plots
        preference_mappping.clusters = []
        preference_mappping.save()
        preference_mappings.append(preference_mappping)
        
    return preference_mappings

def create_user_preferences(usr):
    prods = Product.objects.all()
    if prods and len(prods)>0:
        for prod in prods:
            user_preference = UserPreference()
            user_preference.product = prod
            user_preference.pref_type = PreferenceType.objects.filter(name="UI")[0]
            user_preference.user = usr
            user_preference.save()
            user_preference.pref_mappings = create_preference_mappings(prod)
            user_preference.save()

def decryptPassword(encrypted, passphrase):
    encrypted = base64.b64decode(encrypted)
    IV = encrypted[:16]
    aes = AES.new(passphrase, AES.MODE_CBC, IV)
    data = aes.decrypt(encrypted[16:])
    return data[:-ord(data[-1])]

class LdapLogin(APIView):
    def post(self,request):
        server_name = "ldaps://ds.cisco.com:636"
        parsed_data = request.data
        if 'username' not in parsed_data or len(parsed_data['username']) <= 0:
            return Response({"error":"username is required!"}, HTTP_400_BAD_REQUEST)
        if "password" not in parsed_data or len(parsed_data['password']) <= 0:
            return Response({"error":"password is required!"}, HTTP_400_BAD_REQUEST)
        user_name = parsed_data['username']
        password = parsed_data['password']
        if " " in password:
            password = password.replace(" ",'+')
        password = decryptPassword(password, "1234567890123456")
        try:
            s = Server(server_name, get_info=ALL)
            c = Connection(s, user=user_name,password=password)
            if not c.bind():
                return Response({"error":"Invalid credentials!"}, status=HTTP_400_BAD_REQUEST)
            user_obj = User.objects.filter(username=user_name)
            if len(user_obj)==0:
                usr = User()
                usr.username = user_name
                usr.date_joined=datetime.now()
                usr.save()
                token, created = Token.objects.get_or_create(user=usr)
                create_user_preferences(usr)
            else:
                token, created = Token.objects.get_or_create(user=user_obj[0])
            token.created = timezone.now()
            token.save()
    
            return Response({'token': token.key}, HTTP_200_OK)
        except:
            return Response({"error":"Please try again!"}, status=HTTP_400_BAD_REQUEST)

class UserPreferenceAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    serializer_class = UserPreferenceSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        usr = self.request.user
        user_prefs = UserPreference.objects.filter(user=usr)
        return user_prefs
    
    def post(self,request,format=None):
        usr = request.user.username
        print usr
        parsed_data = request.data
        parsed_data['user'] = str(usr)
        print parsed_data
        serializer = UserPreferenceWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

class UserPreferenceUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = UserPreferenceSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return UserPreference.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return UserPreferenceWriteSerializer
        return UserPreferenceSerializer

class PreferenceMappingAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = PreferenceMappingSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceMapping.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PreferenceMappingWriteSerializer
        return PreferenceMappingSerializer

class PreferenceMappingUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = PreferenceMappingSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceMapping.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PreferenceMappingWriteSerializer
        return PreferenceMappingSerializer

class CustomUserPreferencesAPIView(APIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    def get(self,request, format=None):
        usr = request.user
        print usr
        res = []
        res_obj = {}
        user_prefs = UserPreference.objects.filter(user=usr)
        prods = Product.objects.all()
        if len(user_prefs) <=0 :
            for p in prods:
                res_obj = {}
                prod_obj = {}
                prod_obj['name'] = p.name
                prod_obj['key'] = p.key
                #prod_obj['flag'] = True
                prod_obj['flag'] = False
                res_obj['product'] = prod_obj
                pref_maps = []
                plots = []
                for plot in p.plots.all():
                    plot_obj = {}
                    plot_obj['name'] = plot.name
                    plot_obj['key'] = plot.key
                    #plot_obj['flag'] = True
                    plot_obj['flag'] = False
                    plots.append(plot_obj)
                if len(p.clusters.all()) > 0 :
                    for c in p.clusters.all():
                        map_obj = {}
                        cluster_obj = {}
                        cluster_obj['name'] = c.name
                        cluster_obj['key'] = c.key
                        #cluster_obj['flag'] = True
                        cluster_obj['flag'] = False
                        map_obj['cluster'] = cluster_obj
                        map_obj['plots'] = plots
                        pref_maps.append(map_obj)
                else:
                    map_obj = {}
                    map_obj['plots'] = plots
                    map_obj['map_key'] = None
                    pref_maps.append(map_obj)
                res_obj['mappings'] = pref_maps
                res_obj['account_user'] = "default"
                res.append(res_obj)
        else:
            for p in prods:
                cnt = 0
                for pref in user_prefs:
                    if p.name == pref.product.name:
                        pref_map_objs = pref.pref_mappings
                        res_obj = {}
                        pref_maps =[]
                        prod_obj = {}
                        prod_obj['name'] = p.name
                        prod_obj['key'] = p.key
                        prod_obj['flag'] = True
                        res_obj['product'] = prod_obj
                        non_plots = []
                        for plot in p.plots:
                            plot_obj = {}
                            plot_obj['name'] = plot.name
                            plot_obj['key'] = plot.key
                            plot_obj['flag'] = False
                            non_plots.append(plot_obj) 
                        if len(p.clusters)>0:
                            for cluster in p.clusters:
                                i = 0
                                flag = False
                                for i in range(len(pref_map_objs)):
                                    pref_plots = []
                                    for pp in pref_map_objs[i].plots:
                                        pref_plots.append(pp.name)
                                    map_obj = {}
                                    if cluster in pref_map_objs[i].clusters:
                                        flag=True
                                        plots = []
                                        cluster_obj = {}
                                        cluster_obj['name'] = cluster.name
                                        cluster_obj['key'] = cluster.key
                                        cluster_obj['flag'] = True
                                        map_obj['cluster'] = cluster_obj
                                        map_obj['map_key'] = pref_map_objs[i].key
                                        for np in non_plots:
                                            if np['name'] in pref_plots:
                                                ob = {}
                                                ob['flag'] = True
                                                ob['name'] = np['name']
                                                ob['key'] = np['key']
                                                plots.append(ob)
                                            else:
                                                plots.append(np)
                                        map_obj['plots'] = plots
                                        pref_maps.append(map_obj)
                                        break
                                if i+1 >= len(pref_map_objs) and not flag:
                                    map_obj = {}
                                    cluster_obj = {}
                                    cluster_obj['name'] = cluster.name
                                    cluster_obj['key'] = cluster.key
                                    cluster_obj['flag'] = False
                                    map_obj['cluster'] = cluster_obj
                                    map_obj['plots'] = non_plots
                                    map_obj['map_key'] = None
                                    pref_maps.append(map_obj)
                        else:
                            map_obj = {}
                            plots = []
                            i = 0
                            flag = False
                            for i in range(len(pref_map_objs)):
                                pref_plots = []
                                for pp in pref_map_objs[i].plots:
                                    pref_plots.append(pp.name)
                            map_obj['map_key'] = pref_map_objs[i].key
                            for np in non_plots:
                                if np['name'] in pref_plots:
                                    ob = {}
                                    ob['flag'] = True
                                    ob['name'] = np['name']
                                    ob['key'] = np['key']
                                    plots.append(ob)
                                else:
                                    plots.append(np)
                            map_obj['plots'] = plots
                            pref_maps.append(map_obj)
                        res_obj['mappings'] = pref_maps
                        res_obj['user'] = pref.user.username
                        res_obj['pref_key'] = pref.key
                        res.append(res_obj)
                    else:
                        cnt = cnt +1
                if cnt >= len(user_prefs):
                    res_obj = {}
                    prod_obj = {}
                    prod_obj['name'] = p.name
                    prod_obj['key'] = p.key
                    prod_obj['flag'] = False
                    res_obj['product'] = prod_obj
                    pref_maps = []
                    plots = []
                    for plot in p.plots.all():
                        plot_obj = {}
                        plot_obj['name'] = plot.name
                        plot_obj['key'] = plot.key
                        plot_obj['flag'] = False
                        plots.append(plot_obj)
                    if len(p.clusters.all()) > 0 :
                        for c in p.clusters.all():
                            map_obj = {}
                            cluster_obj = {}
                            cluster_obj['name'] = c.name
                            cluster_obj['key'] = c.key
                            cluster_obj['flag'] = False
                            map_obj['cluster'] = cluster_obj
                            map_obj['plots'] = plots
                            pref_maps.append(map_obj)
                    else:
                        map_obj = {}
                        map_obj['plots'] = plots
                        map_obj['map_key'] = None
                        pref_maps.append(map_obj)
                    res_obj['mappings'] = pref_maps
                    res_obj['account_user'] = "default"
                    res_obj['pref_key'] = None
                    res.append(res_obj)
        return Response(res,status=HTTP_200_OK)