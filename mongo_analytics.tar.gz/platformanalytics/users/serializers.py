from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from common.models import *
from users.models import *
from common.serializers import *
from mongoengine.django.auth import User

class UserSerializer(mongoserializers.DocumentSerializer):
    plots = PlotSerializer(many=True)
    clusters = ClusterSerializer(many=True)
    class Meta:
        model = User
        fields = ['username','date_joined']

class PreferenceMappingSerializer(mongoserializers.DocumentSerializer):
    plots = PlotSerializer(many=True)
    clusters = ClusterSerializer(many=True)
    class Meta:
        model = PreferenceMapping
        fields = ['key', 'plots','clusters']
    
class PreferenceMappingWriteSerializer(mongoserializers.DocumentSerializer):
    plots = serializers.SlugRelatedField(
        queryset=Plot.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    clusters = serializers.SlugRelatedField(
        queryset=Cluster.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    class Meta:
        model = PreferenceMapping
        fields = ['key', 'plots','clusters']

class UserPreferenceSerializer(mongoserializers.DocumentSerializer):
    product = ProductShortSerializer()
    user = serializers.SlugRelatedField(
        queryset=User.objects.all(),
        slug_field='username')
    pref_type = serializers.SlugRelatedField(
        queryset=User.objects.all(),
        slug_field='name')
    pref_mappings = PreferenceMappingSerializer(many=True)
    class Meta:
        model = UserPreference
        fields = ['key','product','pref_mappings','pref_type','user']
    
class UserPreferenceWriteSerializer(mongoserializers.DocumentSerializer):
    product = serializers.SlugRelatedField(
        queryset=Product.objects.all(),
        slug_field='key')
    user = serializers.SlugRelatedField(
        queryset=User.objects.all(),
        slug_field='username')
    pref_type = serializers.SlugRelatedField(
        queryset=PreferenceType.objects.all(),
        slug_field='name')
    pref_mappings = serializers.SlugRelatedField(
        queryset=PreferenceMapping.objects.all(),
        slug_field='key',
        required=False,allow_null=True,many=True) 
    class Meta:
        model = UserPreference
        fields = ['key','product','pref_mappings','pref_type','user']

        