from __future__ import unicode_literals
import binascii, os
from django.db import models
import uuid
from django.utils import timezone
import mongoengine
from mongoengine import Document, fields, EmbeddedDocument
from mongoengine import signals
from mongoengine.django.auth import User
from dateutil.parser import parse
# Create your models here.

class Cucmdata(Document):
    cdrRecordType = fields.IntField(default=0, null=True)
    globalCallID_callManagerId = fields.IntField(default=0, null=True)
    globalCallID_callId = fields.IntField(default=0, null=True,required=True)
    origLegCallIdentifier = fields.IntField(default=0, null=True)
    dateTimeOrigination = fields.IntField(default=0, null=True)
    origNodeId = fields.IntField(default=0, null=True)
    origSpan = fields.IntField(default=0, null=True)
    origIpAddr = fields.IntField(default=0, null=True)
    callingPartyNumber = fields.StringField(default="", null=True)
    callingPartyUnicodeLoginUserID = fields.StringField(default="", null=True)
    origCause_location = fields.IntField(default=0, null=True)
    origCause_value = fields.IntField(default=0, null=True)
    origPrecedenceLevel = fields.IntField(default=0, null=True)
    origMediaTransportAddress_IP = fields.IntField(default=0, null=True)
    origMediaTransportAddress_Port = fields.IntField(default=0, null=True)
    origMediaCap_payloadCapability = fields.IntField(default=0, null=True)
    origMediaCap_maxFramesPerPacket = fields.IntField(default=0, null=True)
    origMediaCap_g723BitRate = fields.IntField(default=0, null=True)
    origVideoCap_Codec = fields.IntField(default=0, null=True)
    origVideoCap_Bandwidth = fields.IntField(default=0, null=True)
    origVideoCap_Resolution = fields.IntField(default=0, null=True)
    origVideoTransportAddress_IP = fields.IntField(default=0, null=True)
    origVideoTransportAddress_Port = fields.IntField(default=0, null=True)
    origRSVPAudioStat = fields.StringField(default="", null=True)
    origRSVPVideoStat = fields.StringField(default="", null=True)
    destLegIdentifier = fields.IntField(default=0, null=True)
    destNodeId = fields.IntField(default=0, null=True)
    destSpan = fields.IntField(default=0, null=True)
    destIpAddr = fields.IntField(default=0, null=True)
    originalCalledPartyNumber = fields.StringField(default="", null=True)
    finalCalledPartyNumber = fields.StringField(default="", null=True)
    finalCalledPartyUnicodeLoginUserID = fields.IntField(default=0, null=True)
    destCause_location = fields.IntField(default=0, null=True)
    destCause_value = fields.IntField(default=0, null=True)
    destPrecedenceLevel = fields.IntField(default=0, null=True)
    destMediaTransportAddress_IP = fields.IntField(default=0, null=True)
    destMediaTransportAddress_Port = fields.IntField(default=0, null=True)
    destMediaCap_payloadCapability = fields.IntField(default=0, null=True)
    destMediaCap_maxFramesPerPacket = fields.IntField(default=0, null=True)
    destMediaCap_g723BitRate = fields.IntField(default=0, null=True)
    destVideoCap_Codec = fields.IntField(default=0, null=True)
    destVideoCap_Bandwidth = fields.IntField(default=0, null=True)
    destVideoCap_Resolution = fields.IntField(default=0, null=True)
    destVideoTransportAddress_IP = fields.IntField(default=0, null=True)
    destVideoTransportAddress_Port = fields.IntField(default=0, null=True)
    destRSVPAudioStat = fields.StringField(default="", null=True)
    destRSVPVideoStat = fields.StringField(default="", null=True)
    dateTimeConnect = fields.IntField(default=0, null=True)
    dateTimeDisconnect = fields.IntField(default=0, null=True)
    lastRedirectDn = fields.StringField(default="", null=True)
    pkid = fields.StringField(unique=True)
    originalCalledPartyNumberPartition = fields.StringField(default="", null=True)
    callingPartyNumberPartition = fields.StringField(default="", null=True)
    finalCalledPartyNumberPartition = fields.StringField(default="", null=True)
    lastRedirectDnPartition = fields.StringField(default="", null=True)
    duration = fields.IntField(default=0, null=True)
    origDeviceName = fields.StringField(default="", null=True)
    destDeviceName = fields.StringField(default="", null=True)
    origCallTerminationOnBehalfOf = fields.IntField(default=0, null=True)
    destCallTerminationOnBehalfOf = fields.IntField(default=0, null=True)
    origCalledPartyRedirectOnBehalfOf = fields.IntField(default=0, null=True)
    lastRedirectRedirectOnBehalfOf = fields.IntField(default=0, null=True)
    origCalledPartyRedirectReason = fields.IntField(default=0, null=True)
    lastRedirectRedirectReason = fields.IntField(default=0, null=True)
    destConversationId = fields.IntField(default=0, null=True)
    globalCallId_ClusterID = fields.StringField(default="", null=True)
    joinOnBehalfOf = fields.IntField(default=0, null=True)
    comment = fields.StringField(default="", null=True)
    authCodeDescription = fields.StringField(default="", null=True)
    authorizationLevel = fields.IntField(default=0, null=True)
    clientMatterCode = fields.StringField(default="", null=True)
    origDTMFMethod = fields.IntField(default=0, null=True)
    destDTMFMethod = fields.IntField(default=0, null=True)
    callSecuredStatus = fields.IntField(default=0, null=True)
    origConversationId = fields.IntField(default=0, null=True)
    origMediaCap_Bandwidth = fields.IntField(default=0, null=True)
    destMediaCap_Bandwidth = fields.IntField(default=0, null=True)
    authorizationCodeValue = fields.StringField(default="", null=True)
    outpulsedCallingPartyNumber = fields.StringField(default="", null=True)
    outpulsedCalledPartyNumber = fields.StringField(default="", null=True)
    origIpv4v6Addr = fields.StringField(default="", null=True)
    destIpv4v6Addr = fields.StringField(default="", null=True)
    origVideoCap_Codec_Channel2 = fields.StringField(default="", null=True)
    origVideoCap_Bandwidth_Channel2 = fields.StringField(default="", null=True)
    origVideoCap_Resolution_Channel2 = fields.StringField(default="", null=True)
    origVideoTransportAddress_IP_Channel2 = fields.StringField(default="", null=True)
    rigVideoTransportAddress_Port_Channel2 = fields.StringField(default="", null=True)
    origVideoChannel_Role_Channel2 = fields.StringField(default="", null=True)
    destVideoCap_Codec_Channel2 = fields.StringField(default="", null=True)
    destVideoCap_Bandwidth_Channel2 = fields.StringField(default="", null=True)
    destVideoCap_Resolution_Channel2 = fields.StringField(default="", null=True)
    destVideoTransportAddress_IP_Channel2 = fields.StringField(default="", null=True)
    destVideoTransportAddress_Port_Channel2 = fields.StringField(default="", null=True)
    destVideoChannel_Role_Channel2 = fields.StringField(default="", null=True)
    origVideoTransportAddress_Port_Channel2 = fields.StringField(default="", null=True)
    IncomingProtocolID = fields.IntField(default=0, null=True)
    IncomingProtocolCallRef = fields.StringField(default="", null=True)
    OutgoingProtocolID = fields.IntField(default=0, null=True)
    OutgoingProtocolCallRef = fields.StringField(default="", null=True)
    currentRoutingReason = fields.IntField(default=0, null=True)
    origRoutingReason = fields.IntField(default=0, null=True)
    lastRedirectingRoutingReason = fields.IntField(default=0, null=True)
    huntPilotPartition = fields.StringField(default="", null=True)
    huntPilotDN = fields.StringField(default="", null=True)
    calledPartyPatternUsage = fields.IntField(default=0, null=True)
    IncomingICID = fields.StringField(default="", null=True)
    IncomingOrigIOI = fields.StringField(default="", null=True)
    IncomingTermIOI = fields.StringField(default="", null=True)
    OutgoingICID = fields.StringField(default="", null=True)
    OutgoingOrigIOI = fields.StringField(default="", null=True)
    OutgoingTermIOI = fields.StringField(default="", null=True)
    outpulsedOriginalCalledPartyNumber = fields.StringField(default="", null=True)
    outpulsedLastRedirectingNumber = fields.StringField(default="", null=True)
    callingPartyNumber_uri = fields.StringField(default="", null=True)
    finalCalledPartyNumber_uri = fields.StringField(default="", null=True)
    lastRedirectDn_uri = fields.StringField(default="", null=True)
    originalCalledPartyNumber_uri = fields.StringField(default="", null=True)
    totalWaitTimeInQueue = fields.IntField(default=0, null=True)
    wasCallQueued = fields.IntField(default=0, null=True)
    mobileCallingPartyNumber = fields.StringField(default="", null=True)
    finalMobileCalledPartyNumber = fields.StringField(default="", null=True)
    origMobileDeviceName = fields.StringField(default="", null=True)
    destMobileDeviceName = fields.StringField(default="", null=True)
    origMobileCallDuration = fields.StringField(default="", null=True)
    destMobileCallDuration = fields.StringField(default="", null=True)
    mobileCallType = fields.StringField(default="", null=True)
    originalCalledPartyPattern = fields.StringField(default="", null=True)
    finalCalledPartyPattern = fields.StringField(default="", null=True)
    lastRedirectingPartyPattern = fields.StringField(default="", null=True)
    huntPilotPattern = fields.StringField(default="", null=True)
    origModelDescription = fields.StringField(default="", null=True)
    origModel = fields.StringField(default="", null=True)
    destModelDescription = fields.StringField(default="", null=True)
    destModel = fields.StringField(default="", null=True)
    date = fields.DateTimeField(null=True)
    fmtVideoStr = fields.StringField(default="", null=True)
    fmtAudioStr = fields.StringField(default="", null=True)
    fmtCodec = fields.StringField(default="", null=True)
    fmtAVType = fields.StringField(default="", null=True)
    fmtCause = fields.StringField(default="", null=True)
    fmtStatus = fields.StringField(default="", null=True)
    fmtBehalfOf = fields.StringField(default="", null=True)
    fmtRReason = fields.StringField(default="", null=True)
    fmtSecureStat = fields.StringField(default="", null=True)
    newOrigIP = fields.StringField(default="", null=True)
    newDestIp = fields.StringField(default="", null=True)
    callType = fields.StringField(default="", null=True)
    version = fields.StringField(default="", null=True)
    cluster = fields.StringField(default="", null=True)
    talktime_duration = fields.DecimalField(default=0,null=True,precision=10)
    talktime = fields.StringField(default="", null=True)
    fmtCloudType = fields.StringField(default="", null=True)
    count = fields.IntField(default=1)
    origUsername = fields.StringField(default="", null=True)
    destUsername = fields.StringField(default="", null=True)
    call_scenarios = fields.StringField(default="", null=True)
    meta = {
        'indexes':[{'fields':("pkid",), 'sparse':True},
                   {'fields':("origModelDescription",), 'sparse':True},
                   {'fields':("origModel",), 'sparse':True},
                   {'fields':("dateTimeOrigination",), 'sparse':True},
                   {'fields':("destModelDescription",), 'sparse':True},
                   {'fields':("destModel",), 'sparse':True},
                   {'fields':("date",), 'sparse':True},
                   {'fields':("fmtVideoStr",), 'sparse':True},
                   {'fields':("fmtAudioStr",), 'sparse':True},
                   {'fields':("fmtCodec",), 'sparse':True},
                   {'fields':("fmtAVType",), 'sparse':True},
                   {'fields':("fmtCause",), 'sparse':True},
                   {'fields':("fmtStatus",), 'sparse':True},
                   {'fields':("fmtBehalfOf",), 'sparse':True},
                   {'fields':("fmtRReason",), 'sparse':True},
                   {'fields':("fmtSecureStat",), 'sparse':True},
                   {'fields':("newOrigIP",), 'sparse':True},
                   {'fields':("globalCallID_callId",), 'sparse':True},
                   {'fields':("newDestIp",), 'sparse':True},
                   {'fields':("callType",), 'sparse':True},
                   {'fields':("cluster",), 'sparse':True},
                   {'fields':("talktime_duration",), 'sparse':True},
                   {'fields':("talktime",), 'sparse':True},
                   {'fields':("fmtCloudType",), 'sparse':True},
                   {'fields':("count",), 'sparse':True},
                   {'fields':("origUsername",), 'sparse':True},
                   {'fields':("destUsername",), 'sparse':True},
                   {'fields':("call_scenarios",), 'sparse':True}]
        }

class Cucmversion(Document):
    cluster = fields.StringField(required=True)
    version = fields.StringField(required=True)
    changeDate = fields.DateTimeField(required=True)
    meta = {
        'indexes':[{'fields':("cluster","version",), 'unique':True}]
        }

class Cucmuserinfo(Document):
    count = fields.IntField(default=0)
    cluster = fields.StringField(required=True)
    type = fields.StringField(required=True)
    date = fields.DateTimeField(required=True)
    meta = {
        'indexes':[{'fields':("cluster","type","date",), 'unique':True}]
        }

class Cucmtrunk(Document):
    name = fields.StringField(default="", null=True)
    source = fields.StringField(default="", null=True)
    destination = fields.StringField(default="", null=True)
    type = fields.StringField(default="", null=True)
    cluster = fields.StringField(default="", null=True)
    src_destination = fields.StringField(default="", null=True)
    meta = {
        'indexes':[{'fields':("cluster","type","source","destination","name",), 'unique':True}]
        }

class Cucmdeviceinfo(Document):
    Model = fields.StringField(default="", null=True)
    ActualModel = fields.StringField(default="", null=True)
    Name = fields.StringField(default="", null=True)
    DeviceClass = fields.StringField(default="", null=True)
    LoginUserId = fields.StringField(default="", null=True)
    Status = fields.StringField(default="", null=True)
    Description = fields.StringField(default="", null=True)
    Product = fields.StringField(default="", null=True)
    BoxProduct = fields.StringField(default="", null=True)
    Httpd = fields.StringField(default="", null=True)
    RegistrationAttempts = fields.StringField(default="", null=True)
    IsCtiControllable = fields.StringField(default="", null=True)
    StatusReason = fields.StringField(default="", null=True)
    TimeStamp = fields.StringField(default="", null=True)
    Protocol = fields.StringField(default="", null=True)
    ActiveLoadId = fields.StringField(default="", null=True)
    InactiveLoadId = fields.StringField(default="", null=True)
    Cluster = fields.StringField(default="", null=True)
    count = fields.IntField(default = 1)
    meta = {
        'indexes':[{'fields':("Cluster","Name",), 'unique':True}]
        }
    