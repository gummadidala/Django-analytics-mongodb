from django.conf.urls import url
from cucm import views
urlpatterns = [
    url(r'^api/plotcucm/', views.CucmPlotAPIView.as_view()),
    url(r'^api/plotendpoints/', views.CucmPlotAPIView.as_view()),
    url(r'^api/cucmdata/', views.CucmdataAPIView.as_view()),
    url(r'^api/cucmversion/', views.CucmversionAPIView.as_view()),
    url(r'^api/cucmuserinfo/', views.CucmuserinfoAPIView.as_view()),
    url(r'^api/cucmtrunk/', views.CucmtrunkAPIView.as_view()),
    url(r'^api/cucmdeviceinfo/', views.CucmdeviceinfoAPIView.as_view()),
    url(r'^api/endpoints/', views.EndpointsAPIView.as_view()),
    url(r'^api/cucmversions/', views.CUCMVersionsAPIView.as_view()),
]