from django.apps import AppConfig


class CucmConfig(AppConfig):
    name = 'cucm'
