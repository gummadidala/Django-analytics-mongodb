from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from desk.models import *

class DeskdataSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Deskdata
        fields = ['plot','cluster','count','date','type','case_id']