from __future__ import unicode_literals
import binascii, os
from django.db import models
import uuid
from django.utils import timezone
import mongoengine
from mongoengine import Document, fields, EmbeddedDocument
from mongoengine import signals
from mongoengine.django.auth import User
from dateutil.parser import parse

class Deskdata(Document):
    plot = fields.StringField(default="", null=True)
    cluster = fields.StringField(default="", null=True)
    count = fields.IntField()
    type = fields.StringField(default="", null=True)
    date = fields.DateTimeField()
    case_id = fields.StringField(default="", null=True)
    meta = {
        'indexes':[{'fields':("cluster","type","plot","count","date","case_id",), 
                    'unique':True}]
        }