from rest_framework_mongoengine import generics
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from users.authentication import TokenAuthentication, ExpiringTokenAuthentication
from desk.models import *
from rest_framework.views import APIView
from datetime import datetime, timedelta
from dateutil.parser import parse
from desk.utils import *
from desk.serializers import * 
from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from common.models import *

class DeskPlotAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        res = {}
        datasets = []
        list_query_data = []
        types = []
        plot = request.query_params.get('plot', None)
        cluster = request.query_params.get('cluster', None)
        start_date = parse(request.query_params.get('start_date',"2017-07-12")).date()
        end_date = parse(request.query_params.get('end_date',datetime.now().date().strftime("%Y-%m-%d"))).date()#+timedelta(days=1)
        mavg = request.query_params.get('movingAvg', "False")
        eliminate_clusters = ["Sparkans Cloudberry", "Sparkans Sparkboard", "Sparkans Voice/Share"]
        if start_date is None or end_date is None or plot is None:
            return Response({"error":"please provide all mandatory fields like start date, end date and plot!"},status=HTTP_400_BAD_REQUEST)
        if cluster == "ALL":
            cluster = None
        res = get_desk_data(plot, cluster, start_date, end_date, mavg)
        if not res:
            return Response({"error":"Data not found"},status=HTTP_400_BAD_REQUEST)
        else:
            return Response(res,status=HTTP_200_OK)

class DeskdataAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = DeskdataSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Deskdata.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return DeskdataSerializer
        return DeskdataSerializer