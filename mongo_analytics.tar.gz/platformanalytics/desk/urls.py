from django.conf.urls import url
from desk import views
urlpatterns = [
    url(r'^api/plotdesk/', views.DeskPlotAPIView.as_view()),
    url(r'^api/deskdata/', views.DeskdataAPIView.as_view()),
]