from desk.models import *
from mongoengine.queryset.visitor import Q
from datetime import timedelta, datetime
from dateutil.parser import parse
import json
from operator import itemgetter

def re_arrange_dates(query_data, label, min_date, max_date, product=None, cluster=None, plot=None):
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
        
    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['count'] = 0
            obj["call_info"] = []
            query_data.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(query_data, key=lambda x: x['date'])
    
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    
    dataset = {}
    dates = []
    count = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['count'])
        
    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    
    if cluster is not None:
        types_query = Deskdata.objects.filter(type=label, plot=plot, cluster=cluster,
                                              date__gte=datetime.now().date(),
                                              date__lte=datetime.now().date()).only("case_id")
    else:
        types_query = Deskdata.objects.filter(type=label, plot=plot, date__gte=datetime.now().date(),
                                              date__lte=datetime.now().date()).only("case_id")
    if types_query is not None and len(types_query) > 0:
        dataset["cases"] = types_query[0]["case_id"]
    
    return dataset

def Calculate_Moving_Average(data):
    cumsum, moving_aves = [0],[] 
    n = 7
    for i,x in enumerate(data,1):
        cumsum.append(cumsum[i-1] + x)
        if i>=n:
            moving_ave = (cumsum[i] - cumsum[i-n])/n
            moving_aves.append(round(moving_ave,2))
        else:
            moving_aves.append(0)
    obj = {}
    obj['data'] = moving_aves
    obj['label'] = 'MovingAVG'
    return obj

def get_graph_types(plot, cluster):
    graph_types = ["Bar","BarLine","HeatMap","HorizontalBar","Line", "Pie", "Stacked"]

    if plot == "Status Distribution" or plot == "Open Cases Historical Distribution" or plot == "New Cases Historical Distribution" :
            graph_types = ["Stacked", "Bar", "Line"]
    elif plot == "UnResolved Cases" or plot == "UnAssigned Cases":
        if cluster:
            graph_types = ["Pie"]
        else:
            graph_types = ["HorizontalBar","Pie"]
    elif plot == "First Response Time" or plot == "Time To Resolution" or plot == "Cases Reopened":
            graph_types = ["BarLine", "Bar", "Line", "Stacked"]
            
    return graph_types

def get_ylabels(plot):
    yLabel = "Call Count"

    if plot == "Today's Open Cases Status" or plot == "Today's New Cases Status":
            yLabel = "Product name"
    elif plot == "First Response Time" or plot =="Time To Resolution":
        yLabel = "Time in days"
    else:
            yLabel = "Case Count"
        
    return yLabel

def get_aggregation_query():
    group_obj = {'_id':
                   {'date':{"month":{'$month':"$date"}
                            ,"day":{'$dayOfMonth':"$date"},
                            "year":{"$year":"$date"}
                            }
                    },
                   'count':{'$sum':'$count'}
                   }
    return group_obj

def get_desk_data(plot,cluster,start_date,end_date,mavg):
    res = {}
    datasets = []
    list_query_data = []
    eliminate_clusters = ["Sparkans Cloudberry", "Sparkans Sparkboard", "Sparkans Voice/Share"]
    graph_types = get_graph_types(plot,cluster)
    yLabel = get_ylabels(plot)
    if graph_types[0] == "BarLine":
        mavg = "True"
    if plot in ["UnResolved Cases","UnAssigned Cases"]:
        start_date = datetime.now().date()
        end_date = datetime.now().date()
        
    if cluster is not None:
        types_query = Deskdata.objects.filter(plot = plot, cluster = cluster, date__gte = start_date, date__lte = end_date).distinct("type")
    else:
        types_query = Deskdata.objects.filter(plot = plot, date__gte = start_date, date__lte = end_date).distinct("type")
    old_types = types_query
    for typ in types_query:
        if cluster is not None:
            query_res = Deskdata.objects.filter(type = typ, plot = plot,
                                                 cluster = cluster,
                                                 date__gte = start_date, 
                                                 date__lte = end_date).aggregate({"$group":get_aggregation_query()})
        else:
            query_res = Deskdata.objects.filter(type = typ, 
                                                plot = plot, 
                                                date__gte = start_date, 
                                                date__lte = end_date).aggregate({"$group":get_aggregation_query()})
    
        res_arr= []
        for i in query_res:
            obj = {}
            date_st = str(i['_id']['date']['year'])+'-'+str(i['_id']['date']['month'])+'-'+str(i['_id']['date']['day'])
            obj['count'] = i['count']
            obj['date'] = parse(date_st).date()
            res_arr.append(obj)
        query_res = res_arr
        obj = {}
        obj['type'] = typ
        obj['query_data'] = query_res
        list_query_data.append(obj)
    for q_data in list_query_data: 
        res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date, "DESK",cluster,plot)
        datasets.append(res_data)
    if len(datasets) > 0:
        if mavg == "True":
            datasets.append( Calculate_Moving_Average(datasets[0]['data']))
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        if graph_types[0] == "Pie":
            res['labels'] = types_query
        elif graph_types[0] == "HorizontalBar":
            types = []
            types_query = Deskdata.objects.filter(plot = plot, date__gte = start_date, date__lte = end_date).distinct("cluster")
            for q in types_query:
                if q and q not in types and q not in eliminate_clusters:
                    types.append(q)
            res['labels'] = types
            datasets = []
            for typ in old_types:
                data = []
                cases = []
                for cluster in types:
                    query_res = Deskdata.objects.filter(type = typ, plot = plot, 
                                                        cluster = cluster, 
                                                        date__gte = start_date, 
                                                        date__lte = end_date).aggregate({"$group":get_aggregation_query()})
                    if query_res:
                        for q in query_res:
                            data.append(q['count'])
                    else:
                        data.append(0)
                    cases_query = Deskdata.objects.filter(cluster = cluster, 
                                                          type=typ, plot = plot, 
                                                          date__gte = datetime.now().date(), 
                                                          date__lte = datetime.now().date()).only("case_id")
                    if cases_query is not None and len(cases_query)>0:
                        cases.append(cases_query[0]['case_id'])
                    else:
                        cases.append("No Cases")
                obj = {}
                obj['data'] = data
                obj["cases"]=cases
                obj['label'] = typ
                datasets.append(obj)
            res['dataset'] = datasets
        res['graphTypes'] = graph_types
        res['yLabel'] = yLabel
    if not res:
        return None
    else:
        return res