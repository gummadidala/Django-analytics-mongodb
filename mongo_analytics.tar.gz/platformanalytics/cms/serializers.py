from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from cms.models import *

class CmsdataSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Cmsdata
        fields = ['session', 'correlatorindex', 'unixtime', 'callbridge', 'recordindex', 
                  'type', 'pkid', 'name', 'ownername', 'calltype', 'cospace', 
                  'callcorrelator', 'calllegscompleted', 'calllegsmaxactive', 
                  'remoteparty', 'localaddress', 'displayname', 'remoteaddress', 'calllegtype', 
                  'direction', 'groupid', 'sipcallid', 'callid', 'deactivated', 'reason', 
                  'remoteteardown', 'activatedduration', 'calllegdurationseconds', 
                  'mainvideoviewer', 'mainvideocontributor', 'encryptedmedia', 
                  'rxaudio_codec', 'rxaudio_pktlossbursts_duration', 'rxaudio_pktlossbursts_density', 
                  'rxaudio_pktgap_duration', 'rxaudio_pktgap_density', 'txaudio_codec', 
                  'rxvideo_codec', 'rxvideo_maxsizewidth', 'rxvideo_maxsizeheight', 
                  'rxvideo_pktlossbursts_duration', 'rxvideo_pktlossbursts_density', 
                  'rxvideo_pktgap_duration', 'rxvideo_pktgap_density', 'txvideo_codec', 
                  'txvideo_maxsizewidth', 'txvideo_maxsizeheight', 'modifiedcallbridge', 
                  'date', 'version', 'durationseconds', 'calllegid', 'count']