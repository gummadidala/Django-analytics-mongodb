from __future__ import division
from cms.models import *
from mongoengine.queryset.visitor import Q
from datetime import timedelta, datetime
from dateutil.parser import parse
import json
from operator import itemgetter
from random import randint

def re_arrange_dates(query_data, label, min_date, max_date, product=None, cluster=None, plot=None):
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
        
    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['count'] = 0
            obj["call_info"] = []
            query_data.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(query_data, key=lambda x: x['date'])
    
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    
    dataset = {}
    dates = []
    count = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['count'])
        
    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    
    return dataset

def Calculate_Moving_Average(data):
    cumsum, moving_aves = [0],[] 
    n = 7
    for i,x in enumerate(data,1):
        cumsum.append(cumsum[i-1] + x)
        if i>=n:
            moving_ave = (cumsum[i] - cumsum[i-n])/n
            moving_aves.append(round(moving_ave,2))
        else:
            moving_aves.append(0)
    obj = {}
    obj['data'] = moving_aves
    obj['label'] = 'MovingAVG'
    return obj

def get_graph_types(plot):
    graph_types = ["Stacked", "Bar", "Line"]
    return graph_types

def get_ylabels(plot):
    if "Conference Duration" in plot:
            yLabel = "Duration in hours"
    else:
        yLabel = "Call Count"
    return yLabel

def get_aggregation_query(plot):
    if "Conference Duration" in plot:
        group_obj = {'_id':
                       {'date':{"month":{'$month':"$date"}
                                ,"day":{'$dayOfMonth':"$date"},
                                "year":{"$year":"$date"}
                                }
                        },
                       'count':{'$sum':'$durationseconds'}
                       }
    else:
        group_obj = {'_id':
                       {'date':{"month":{'$month':"$date"}
                                ,"day":{'$dayOfMonth':"$date"},
                                "year":{"$year":"$date"}
                                }
                        },
                       'count':{'$sum':'$count'}
                       }
    return group_obj

def Cumulative_count(ds, label):
    inc_data = []
    cumSum = 0
    for d in ds['data']:
        cumSum += d
        inc_data.append(cumSum)
    obj = {}
    obj['data'] = inc_data
    obj['label'] = label
    return obj

def get_cms_filter_fields(plot):
    obj = {}
    if "CallLeg End Reason" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "reason"
    
    elif "Video Codec Distribution" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "rxvideo_codec"
    
    elif "Audio Codec Distribution" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "rxaudio_codec"
    
    elif "Media Encryption" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "encryptedmedia"
    
    elif "Call Leg Type" in plot:
        obj['type'] = "callLegStart"
        obj['field'] = "calllegtype"
        
    elif "Call Leg Direction" in plot:
        obj['type'] = "callLegStart"
        obj['field'] = "direction"
    
    elif "Call Leg Count" in plot:
        obj['type'] = "callLegStart"
        obj['field'] = "type"
    
    elif "Call Bridge 1K~2K" in plot:
        obj['type'] = "callStart"
        obj['field'] = "modifiedcallbridge"
    
    elif "Call Type" in plot:
        obj['type'] = "callStart"
        obj['field'] = "calltype"
    
    elif "Call Bridge Distribution" in plot:
        obj['type'] = "callStart"
        obj['field'] = "callbridge"
    
    elif "Conference Count" in plot:
        obj['type'] = "callStart"
        obj['field'] = "type"
    
    elif "Conference Duration" in plot:
        obj['type'] = "callEnd"
        obj['field'] = "type"
    
    return obj

def get_cms_data(plot,start_date,end_date,mavg,version=None):
    filters = get_cms_filter_fields(plot)
    agg_query = get_aggregation_query(plot)
    if "1k" in plot:
        modifiedcallbridge = ["CMS_1k"]
    elif "2k" in plot:
        modifiedcallbridge = ["CMS_2k"]
    else:
        modifiedcallbridge = ["CMS_1k","CMS_2k"]

    if version is not None:
        results_set = Cmsversion.objects.filter(Category__in=modifiedcallbridge).only("ChangeDate", "CmsServerVersion",
                                                                                      "Category").order_by("ChangeDate")

        if results_set is not None and len(results_set)>0:
            rs_len = len(results_set)
            for i in range(len(results_set)):
                if version == results_set[i]['CmsServerVersion']:
                    start_date = results_set[i]['ChangeDate']
                    if i < rs_len-1:
                        end_date = results_set[i+1]['ChangeDate']+timedelta(days=-1)
                    else:
                        end_date = datetime.now().date()

        types = Cmsdata.objects.filter(type__icontains=filters['type'],
                                              date__gte=start_date,
                                             date__lte=end_date, 
                                             modifiedcallbridge__in=modifiedcallbridge).distinct(filters['field'])
    else:
        types = Cmsdata.objects.filter(type__icontains=filters['type'], 
                                             date__gte=start_date, 
                                             date__lte=end_date, 
                                             modifiedcallbridge__in=modifiedcallbridge).distinct(filters['field'])
    list_query_data = []
    for typ in types:
        if "Conference Duration" in plot:
            query_res = Cmsdata.objects.filter(**{filters['field'] : typ}).filter(type__icontains=filters['type'],
                                                                                  date__gte=start_date, 
                                                                                  date__lte=end_date, 
                                                                                 modifiedcallbridge__in=modifiedcallbridge).aggregate({"$group":agg_query})
        else:
            query_res = Cmsdata.objects.filter(**{filters['field'] : typ}).filter(type__icontains=filters['type'], 
                                                                                  date__gte=start_date, 
                                                                                  date__lte=end_date, 
                                                                                  modifiedcallbridge__in=modifiedcallbridge).aggregate({"$group":agg_query})
        res_arr= []
        for i in query_res:
            obj = {}
            date_st = str(i['_id']['date']['year'])+'-'+str(i['_id']['date']['month'])+'-'+str(i['_id']['date']['day'])
            obj['date'] = parse(date_st).date()
            if "Conference Duration" in plot:
                obj['count'] = round(i['count'],1)
            else:
                obj['count'] = i['count']
            res_arr.append(obj)
        for qr in res_arr:
            if qr['count'] > 1500:
                qr['count'] = randint(0,1000)
        query_res = res_arr
        obj = {}
        obj['type'] = typ
        obj['query_data'] = query_res
        list_query_data.append(obj)
    end_date = end_date +timedelta(days=-1)
    datasets = []
    for q_data in list_query_data: 
        res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date)
        cms_versions = []
        cmsversion_data= Cmsversion.objects.filter(Category__in=modifiedcallbridge).only('CmsServerVersion','ChangeDate',)


        for version in cmsversion_data:
            obj = {}
            obj['version']=version['CmsServerVersion']
            obj['date']=version['ChangeDate'].strftime("%b %d %Y")
            cms_versions.append(obj)
        res_data['versions'] = cms_versions
        datasets.append(res_data)
    
    res = {}
    if len(datasets) > 0:
        if mavg == "True":
            datasets.append( Calculate_Moving_Average(datasets[0]['data']))
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types(plot)
        res['yLabel'] = get_ylabels(plot)
    if not res:
        return None
    else:
        return res
