from django.conf.urls import url
from cms import views
urlpatterns = [
    url(r'^api/plotcms/', views.CmsPlotAPIView.as_view()),
    url(r'^api/cmsdata/', views.CmsdataAPIView.as_view()),
    url(r'^api/cmsversions/', views.CmsVersionsAPIView.as_view()),
]