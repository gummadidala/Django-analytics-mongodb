from rest_framework_mongoengine import generics
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from users.authentication import TokenAuthentication, ExpiringTokenAuthentication
from rest_framework.views import APIView
from datetime import datetime, timedelta
from dateutil.parser import parse
from cms.utils import *
from cms.serializers import * 
from cms.models import *
from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers

class CmsPlotAPIView(APIView):
   def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        res = {}
        datasets = []
        list_query_data = []
        types = []
        plot = request.query_params.get('plot', None)
        version = request.query_params.get('version', None)
        start_date = parse(request.query_params.get('start_date',"2017-08-17")).date()
        end_date = parse(request.query_params.get('end_date',datetime.now().date().strftime("%Y-%m-%d"))).date()+timedelta(days=1)
        mavg = request.query_params.get('movingAvg', "False")
        if start_date is None or end_date is None or plot is None:
            return Response({"error":"please provide all mandatory fields like start date, end date and plot!"},status=HTTP_400_BAD_REQUEST)
        res = get_cms_data(plot, start_date, end_date, mavg,version)
        if not res:
            return Response({"error":"Data not found"},status=HTTP_400_BAD_REQUEST)
        else:
            return Response(res,status=HTTP_200_OK)
            return Response(res,status=HTTP_200_OK)

class CmsdataAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = CmsdataSerializer
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Cmsdata.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CmsdataSerializer
        return CmsdataSerializer
    
class CmsVersionsAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        username = self.request.user.username
        cluster = request.query_params.get('cluster', None)
        product = request.query_params.get('product', None)
        plot=request.query_params.get('plot', None)
        category = request.query_params.get('category', None)
        end_date = datetime.now().date().strftime("%Y-%m-%d")
        start_date =(datetime.now().date() + timedelta(days=-190)).strftime("%Y-%m-%d")
        category_list = []
        if plot is None:
            return Response({"error":"please provide the plot name!"},status=HTTP_400_BAD_REQUEST)
        elif "1k" in plot:
            category_list.append("CMS_1k")
        elif "2k" in plot:
            category_list.append("CMS_2k")
        else:
            category_list =["CMS_1k","CMS_2k"]

        avail_versions = []
        cms_versions = Cmsversion.objects.filter(ChangeDate__gte=start_date, ChangeDate__lte=end_date, Category__in = category_list).only("CmsServerVersion")
        if cms_versions is not None and len(cms_versions)>0:
            for cv in cms_versions:
                if cv['CmsServerVersion'] not in avail_versions and cv['CmsServerVersion'] not in["",None]:
                    avail_versions.append(cv['CmsServerVersion'])

        if 'no version' in avail_versions:
            avail_versions.remove('no version')
        return Response(avail_versions, status = HTTP_200_OK)