from __future__ import unicode_literals
import binascii, os
import uuid
from django.utils import timezone
import mongoengine
from mongoengine import Document, fields, EmbeddedDocument
from mongoengine import signals
from mongoengine.django.auth import User
from dateutil.parser import parse

class Cmsdata(Document):
    session = fields.StringField()
    correlatorindex = fields.IntField(default=0, null=True)
    unixtime = fields.IntField()
    callbridge = fields.StringField(default="", null=True)
    recordindex = fields.IntField(default=0, null=True)
    type = fields.StringField(default="", null=True) 
    pkid = fields.StringField(default="", null=True)
    name = fields.StringField(default="", null=True)
    ownername = fields.StringField(default="", null=True)
    calltype = fields.StringField(default="", null=True)
    cospace = fields.StringField(default="", null=True)
    callcorrelator = fields.StringField(default="", null=True)
    calllegscompleted = fields.IntField(default=0, null=True)
    calllegsmaxactive = fields.IntField(default=0, null=True)
    durationseconds = fields.IntField(default=0, null=True)
    calllegid = fields.StringField(default="", null=True)
    remoteparty = fields.StringField(default="", null=True)
    localaddress = fields.StringField(default="", null=True)
    displayname = fields.StringField(default="", null=True)
    remoteaddress = fields.StringField(default="", null=True)
    calllegtype = fields.StringField(default="", null=True)
    direction = fields.StringField(default="", null=True)
    groupid = fields.StringField(default="", null=True)
    sipcallid = fields.StringField(default="", null=True)
    callid = fields.StringField(default="", null=True)
    deactivated = fields.StringField(default="", null=True)
    reason = fields.StringField(default="", null=True)
    remoteteardown = fields.StringField(default="", null=True)
    activatedduration = fields.IntField(default=0, null=True)
    calllegdurationseconds = fields.IntField(default=0, null=True)
    mainvideoviewer = fields.DecimalField(default=0,null=True,precision=10)
    mainvideocontributor = fields.DecimalField(default=0,null=True,precision=10)
    encryptedmedia = fields.StringField(default="", null=True)
    rxaudio_codec = fields.StringField(default="", null=True)
    rxaudio_pktlossbursts_duration = fields.DecimalField(default=0,null=True,precision=10)
    rxaudio_pktlossbursts_density = fields.DecimalField(default=0,null=True,precision=10)
    rxaudio_pktgap_duration = fields.DecimalField(default=0,null=True,precision=10)
    rxaudio_pktgap_density = fields.DecimalField(default=0,null=True,precision=10)
    txaudio_codec = fields.StringField(default="", null=True)
    rxvideo_codec = fields.StringField(default="", null=True)
    rxvideo_maxsizewidth = fields.IntField(default=0, null=True)
    rxvideo_maxsizeheight = fields.IntField(default=0, null=True)
    rxvideo_pktlossbursts_duration = fields.DecimalField(default=0,null=True,precision=10)
    rxvideo_pktlossbursts_density = fields.DecimalField(default=0,null=True,precision=10)
    rxvideo_pktgap_duration = fields.DecimalField(default=0,null=True,precision=10)
    rxvideo_pktgap_density = fields.DecimalField(default=0,null=True,precision=10)
    txvideo_codec = fields.StringField(default="", null=True)
    txvideo_maxsizewidth = fields.IntField(default=0, null=True)
    txvideo_maxsizeheight = fields.IntField(default=0, null=True)
    modifiedcallbridge = fields.StringField(default="", null=True)
    date = fields.DateTimeField(null=True)
    version = fields.StringField(default="", null=True)
    count = fields.IntField(default=1)
    meta = {
        'indexes':[{'fields':("session","correlatorindex",), 'unique':True},
                   {'fields':("date",), 'sparse':True},
                   {'fields':("modifiedcallbridge",), 'sparse':True},
                   {'fields':("reason",), 'sparse':True},
                   {'fields':("rxvideo_codec",), 'sparse':True},
                   {'fields':("rxaudio_codec",), 'sparse':True},
                   {'fields':("encryptedmedia",), 'sparse':True},
                   {'fields':("calllegtype",), 'sparse':True},
                   {'fields':("type",), 'sparse':True},
                   {'fields':("calltype",), 'sparse':True},
                   {'fields':("callbridge",), 'sparse':True},
                   {'fields':("count",), 'sparse':True},
                   {'fields':("durationseconds",), 'sparse':True}]
        }

class Cmsversion(Document):
    CmsServerVersion = fields.StringField(default="", null=True)
    CmsServerName = fields.StringField(default="", null=True)
    ChangeDate = fields.DateTimeField(default = timezone.now, null=True)
    Category = fields.StringField(default="", null=True)
    meta = {
        'indexes':[{'fields':("CmsServerVersion", "CmsServerName", "ChangeDate", "Category",), 'unique':True}]
        }