from rest_framework_mongoengine import serializers as mongoserializers
from rest_framework import serializers
from jira.models import *

class JiradataSerializer(mongoserializers.DocumentSerializer):
    class Meta:
        model = Jiradata
        fields = ['id', 'issueid', 'issuetype', 'project', 'components', 
                  'origination', 'cap', 'priority', 'severity', 'status', 
                  'created', 'updated', 'assignee', 'creator', 'reporter', 
                  'fixVersions', 'versions', 'count', 'labels', 'resolved']