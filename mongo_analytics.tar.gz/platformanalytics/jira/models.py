from __future__ import unicode_literals
import binascii, os
from django.db import models
import uuid
from django.utils import timezone
import mongoengine
from mongoengine import Document, fields, EmbeddedDocument
from mongoengine import signals
from mongoengine.django.auth import User
from dateutil.parser import parse

class Jiradata(Document):
    issueid = fields.StringField(default="", null=True)
    issuetype = fields.StringField(default="", null=True)
    project = fields.StringField(default="", null=True)
    components = fields.StringField(default="", null=True)
    origination = fields.StringField(default="", null=True)
    cap = fields.StringField(default="", null=True)
    priority = fields.StringField(default="", null=True)
    severity = fields.StringField(default="", null=True)
    status = fields.StringField(default="", null=True)
    created = fields.DateTimeField(null=True)
    updated = fields.DateTimeField(null=True)
    assignee = fields.StringField(default="", null=True)
    creator = fields.StringField(default="", null=True)
    reporter = fields.StringField(default="", null=True)
    fixVersions = fields.StringField(default="", null=True)
    versions = fields.StringField(default="", null=True)
    labels = fields.StringField(default="", null=True)
    count = fields.IntField()
    resolved = fields.DateTimeField(null=True)