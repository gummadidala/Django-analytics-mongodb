from django.apps import AppConfig


class JiraConfig(AppConfig):
    name = 'jira'
