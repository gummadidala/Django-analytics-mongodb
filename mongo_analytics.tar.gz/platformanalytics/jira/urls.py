from django.conf.urls import url
from jira import views
urlpatterns = [
    url(r'^api/plotjira/', views.JiraPlotAPIView.as_view()),
    url(r'^api/jiradata/', views.JiradataAPIView.as_view()),
    url(r'^api/jiraversions/', views.JiraVersionsAPIView.as_view()),
]